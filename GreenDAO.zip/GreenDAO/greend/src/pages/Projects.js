import { useState } from "react";

export default function Projects() {
  const [projects, setProjects] = useState([
    { id: 1, name: "Tree Planting Drive", desc: "Plant 100 trees in the community park.", votes: 12 },
    { id: 2, name: "Recycling in Schools", desc: "Set up recycling bins & awareness sessions.", votes: 8 },
    { id: 3, name: "Solar Street Lights", desc: "Install solar lights in the main square.", votes: 5 },
  ]);

  const handleVote = (id) => {
    const voter = "User123"; // mock user for now
    setProjects((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, votes: p.votes + 1, lastVoter: voter } : p
      )
    );
  };

  return (
    <div className="max-w-5xl mx-auto py-8">
      <h2 className="text-2xl font-bold mb-4">Projects</h2>
      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((p) => (
          <div key={p.id} className="p-5 border rounded-2xl shadow-sm bg-white">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-semibold text-lg">{p.name}</h3>
                <p className="text-gray-600">{p.desc}</p>
                {p.lastVoter && (
                  <p className="text-xs text-gray-500 mt-1">
                    Last voter: {p.lastVoter}
                  </p>
                )}
              </div>
              <span className="px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm">
                {p.votes} votes
              </span>
            </div>
            <button
              onClick={() => handleVote(p.id)}
              className="mt-4 px-4 py-2 rounded-xl bg-green-700 text-white hover:opacity-90"
            >
              Vote
            </button>
            <p className="mt-2 text-xs text-gray-500">
              (Tomorrow this button will write to the blockchain.)
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
