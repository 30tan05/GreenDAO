export default function Transparency({ projects }) {
  const votes = projects.flatMap(p =>
    Array(p.votes).fill().map((_, i) => ({
      project: p.name,
      voter: "User" + (i + 1),
      time: new Date().toLocaleTimeString()
    }))
  );

  return (
    <div className="max-w-5xl mx-auto py-8">
      <h2 className="text-2xl font-bold mb-4">Transparency Records</h2>
      <table className="w-full border rounded-lg bg-white">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2">Project</th>
            <th className="p-2">Voter</th>
            <th className="p-2">Time</th>
          </tr>
        </thead>
        <tbody>
          {votes.length === 0 && (
            <tr>
              <td colSpan="3" className="p-4 text-center text-gray-500">No votes yet.</td>
            </tr>
          )}
          {votes.map((v, i) => (
            <tr key={i} className="border-t">
              <td className="p-2">{v.project}</td>
              <td className="p-2">{v.voter}</td>
              <td className="p-2">{v.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
