import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="max-w-5xl mx-auto py-12 text-center">
      {/* Hero Section */}
      <h1 className="text-4xl font-bold mb-4">
        Welcome to <span className="text-green-700">GreenDAO</span>
      </h1>
      <p className="text-gray-600 mb-6">
        A transparent, community-driven platform for funding and supporting
        sustainability projects.
      </p>
      <div className="space-x-4 mb-12">
        <Link
          to="/projects"
          className="px-6 py-3 rounded-xl bg-green-700 text-white hover:opacity-90"
        >
          Explore Projects
        </Link>
        <Link
          to="/transparency"
          className="px-6 py-3 rounded-xl bg-gray-200 text-gray-800 hover:bg-gray-300"
        >
          View Transparency
        </Link>
      </div>

      {/* How it Works */}
      <h2 className="text-2xl font-semibold mb-6">How it works</h2>
      <div className="grid md:grid-cols-3 gap-6 text-left">
        <div className="p-6 border rounded-2xl bg-white shadow-sm">
          <h3 className="font-semibold mb-2">1. Browse Projects</h3>
          <p className="text-gray-600">
            Discover community ideas for a greener future.
          </p>
        </div>
        <div className="p-6 border rounded-2xl bg-white shadow-sm">
          <h3 className="font-semibold mb-2">2. Cast Your Vote</h3>
          <p className="text-gray-600">
            Support the projects that matter to you most.
          </p>
        </div>
        <div className="p-6 border rounded-2xl bg-white shadow-sm">
          <h3 className="font-semibold mb-2">3. Track Results</h3>
          <p className="text-gray-600">
            Every vote is recorded transparently for accountability.
          </p>
        </div>
      </div>

      {/* Why GreenDAO Section */}
      <h2 className="text-2xl font-semibold mt-16 mb-6">Why GreenDAO?</h2>
      <div className="grid md:grid-cols-3 gap-6 text-left">
        <div className="p-6 border rounded-2xl bg-white shadow-sm">
          <h3 className="font-semibold mb-2">🌱 Transparency</h3>
          <p className="text-gray-600">
            Every vote and fund allocation is visible to everyone. No hidden
            decisions.
          </p>
        </div>
        <div className="p-6 border rounded-2xl bg-white shadow-sm">
          <h3 className="font-semibold mb-2">🤝 Community First</h3>
          <p className="text-gray-600">
            Decisions are made together. Your voice directly shapes local
            projects.
          </p>
        </div>
        <div className="p-6 border rounded-2xl bg-white shadow-sm">
          <h3 className="font-semibold mb-2">🌍 Real Impact</h3>
          <p className="text-gray-600">
            Support initiatives like tree planting, clean energy, and recycling
            drives.
          </p>
        </div>
      </div>

      {/* Call to Action */}
      <div className="mt-16 p-8 bg-green-700 text-white rounded-2xl text-center">
        <h2 className="text-2xl font-bold mb-4">Be part of the change 🌎</h2>
        <p className="mb-6">
          Join us in building a sustainable future with community-powered
          decisions.
        </p>
        <Link
          to="/projects"
          className="px-6 py-3 rounded-xl bg-white text-green-700 font-semibold hover:opacity-90"
        >
          Get Started
        </Link>
      </div>
    </div>
  );
}
