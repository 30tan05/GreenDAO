import { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/NavBar";
import Home from "./pages/Home";
import Projects from "./pages/Projects";
import Transparency from "./pages/Transparency";

function App() {
  const [projects, setProjects] = useState([
    { id: 1, name: "Tree Planting Drive", desc: "Plant 100 trees in the community park.", votes: 12 },
    { id: 2, name: "Recycling in Schools", desc: "Set up recycling bins & awareness sessions.", votes: 8 },
    { id: 3, name: "Solar Street Lights", desc: "Install solar lights in the main square.", votes: 5 },
  ]);

  return (
    <Router>
      <Navbar />
      <main className="min-h-screen bg-gray-50">
        <div className="p-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route
              path="/projects"
              element={<Projects projects={projects} setProjects={setProjects} />}
            />
            <Route
              path="/transparency"
              element={<Transparency projects={projects} />}
            />
          </Routes>
        </div>
      </main>
      <footer className="text-center text-xs text-gray-500 py-6">
        © {new Date().getFullYear()} GreenDAO — Transparent community governance for sustainability
      </footer>
    </Router>
  );
}

export default App;
