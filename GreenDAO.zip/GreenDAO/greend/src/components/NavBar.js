import { Link, NavLink } from "react-router-dom";
import ConnectWallet from "./ConnectWallet";

export default function Navbar() {
  // Tailwind classes for NavLink styling
  const linkClass = "px-3 py-2 rounded hover:bg-green-600 transition-colors";

  return (
    <nav className="sticky top-0 z-10 bg-green-700 text-white">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="font-extrabold tracking-wide text-lg">
          GreenDAO
        </Link>

        {/* Navigation links + ConnectWallet */}
        <div className="flex gap-2 items-center">
          <NavLink to="/" className={linkClass} end>
            Home
          </NavLink>
          <NavLink to="/projects" className={linkClass}>
            Projects
          </NavLink>
          <NavLink to="/transparency" className={linkClass}>
            Transparency
          </NavLink>

          <ConnectWallet />
        </div>
      </div>
    </nav>
  );
}
