import { useState } from "react";
import { BrowserProvider } from "ethers";

export default function ConnectWallet() {
  const [account, setAccount] = useState("");

  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        // Request accounts from MetaMask
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
        setAccount(accounts[0]);

        // ethers v6: BrowserProvider
        const provider = new BrowserProvider(window.ethereum);

        // Get signer (async)
        const signer = await provider.getSigner();
        console.log("Connected signer:", signer);
        console.log("Connected account:", accounts[0]);
      } catch (err) {
        console.error("Error connecting wallet:", err);
      }
    } else {
      alert("MetaMask not found. Please install MetaMask!");
    }
  };

  return (
    <button
      onClick={connectWallet}
      className="bg-white text-green-700 px-4 py-2 rounded hover:bg-gray-200 transition-colors"
    >
      {account ? account.slice(0, 6) + "..." + account.slice(-4) : "Connect Wallet"}
    </button>
  );
}
