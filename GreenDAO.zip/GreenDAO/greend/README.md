# GreenDAO 🌱

### Problem Statement
Local sustainability initiatives such as tree planting, recycling drives, and clean energy adoption often face a major challenge: lack of transparency and trust in how decisions are made and funds are allocated. Donors worry their contributions may not reach the intended project. Community members may feel their votes or voices are ignored. This erodes trust and slows down genuine impact.

### Our Solution
We built **GreenDAO**, a community governance platform. It allows citizens to vote transparently on local green initiatives and track how votes are counted. Every vote is recorded to simulate a public ledger, ensuring fairness and trust.

### Core Features (MVP)
- **Frontend Voting Dashboard**
  - List of sustainability projects (tree planting, solar lights, recycling).
  - Users can cast votes.
- **Transparency Page**
  - A “public ledger” table showing votes and voters.
- **Optional Wallet Integration**
  - Can connect MetaMask for real blockchain interaction (future feature).
